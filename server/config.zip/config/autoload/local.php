<?php
return array(
   'db' => array(
      'username' => 'service3',
      'password' => 'n2Os33MM',
   ),
);

return array(
  'doctrine' => array(
    'connection' => array(
      'orm_default' => array(
        'driverClass' => 'Doctrine\DBAL\Driver\PDOMySql\Driver',
        'params' => array(
          'host'     => 'localhost',
          'port'     => '3306',
          'user'     => 'service3',
          'password' => 'n2Os33MM',
          'dbname'   => 'service3'
        )
      )
    )
  ),
);